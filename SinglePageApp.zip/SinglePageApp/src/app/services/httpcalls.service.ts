import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
@Injectable()
export class HttpcallsService {

   
  public resturl: string = 'https://13.235.74.180:8080/ECTSchool/';
  constructor(private http: HttpClient) { }

  getAllCourse() {
    return this.http.get<any>('https://13.235.74.180:8080/ECTSchool/getAllCollegeCourses')
      .toPromise()
      .then(res => { console.log('In getAllCourse ' + res); return <any[]>res; });
  }
  getAllSemester() {
    return this.http.get<any>('https://13.235.74.180:8080/ECTSchool/getAllCollegeSemesters')
      .toPromise()
      .then(res => { console.log('In getAllSemester ' + res); return <any[]>res; });
  }
  getCourseTimetable(courseId, SemesterId, WeekId) {
    return this.http.get<any>('https://13.235.74.180:8080/ECTSchool/timetable/' + courseId + '/' + SemesterId + '/' + WeekId)
      .toPromise()
      .then(res => { console.log('In getCourseTimetable ' + res); return <any[]>res; });
  }
  addCourseTimeTable(itemObj: any) {
    return this.http.post('https://13.235.74.180:8080/ECTSchool/timetable/', itemObj)
      .toPromise();
  }
  updateCourseTimeTable(itemObj: any) {
    return this.http.put('https://13.235.74.180:8080/ECTSchool/timetable/', itemObj)
      .toPromise();
  }

  getAllWorkWeeks() {
    return this.http.get<any>('https://13.235.74.180:8080/ECTSchool/getAllWorkWeeks')
      .toPromise()
      .then(res => { console.log('In getAllWorkWeeks ' + res); return <any[]>res; });
  }

  getWorkingDaysForWeek(weekId) {
    return this.http.get<any>('https://13.235.74.180:8080/ECTSchool/getWorkingDaysForWeek/' + weekId)
      .toPromise()
      .then(res => { console.log('In getWorkingDaysForWeek ' + res); return <any[]>res; });
  }

  getCourseSubjects(courseId): any {
    return this.http.get<any>('https://13.235.74.180:8080/ECTSchool/getClassSubjectsByGradeId?id='
    + courseId)
    .toPromise()
    .then(res => { console.log('In getCourseSubjects ' + res); return <any[]>res; });
  }

  getAllItems(itemId) {
    return this.http.get<any>(this.resturl + 'getAllItems/' + itemId)
      .toPromise()
      .then(res => { console.log('In getAllItems ' + res); return <any[]>res; });
  }

  getAllItemCount() {
    return this.http.get<any>(this.resturl + 'reports/allitemcount')
      .toPromise()
      .then(res => { console.log('In getAllItemCount ' + res); return <any[]>res; });
  }
  getTenYearOldData() {
    return this.http.get<any>(this.resturl + 'reports/tenyearsolditem')
      .toPromise()
      .then(res => { console.log('In getTenYearOldData ' + res); return <any[]>res; });
  }
  getAMCList() {
    return this.http.get<any>(this.resturl + 'reports/amclist')
      .toPromise()
      .then(res => { console.log('In getAMCList ' + res); return <any[]>res; });
  }
  getCalibiratedList() {
    return this.http.get<any>(this.resturl + 'reports/calibratedlist')
      .toPromise()
      .then(res => { console.log('In getCalibiratedList ' + res); return <any[]>res; });
  }
  getLifeCompletedList() {
    return this.http.get<any>(this.resturl + 'reports/lifecompleted')
      .toPromise()
      .then(res => { console.log('In getLifeCompletedList ' + res); return <any[]>res; });
  }
  getNextMonthMaintenance() {
    return this.http.get<any>(this.resturl + 'reports/nextmonthmaintenance')
      .toPromise()
      .then(res => { console.log('In getNextMonthMaintenance ' + res); return <any[]>res; });
  }
  getSoftwareRenewal() {
    return this.http.get<any>(this.resturl + 'reports/softwarelist')
      .toPromise()
      .then(res => { console.log('In getSoftwareRenewal ' + res); return <any[]>res; });
  }
  getFirefighting() {
    return this.http.get<any>(this.resturl + 'reports/fireextservicelist')
      .toPromise()
      .then(res => { console.log('In getFirefighting ' + res); return <any[]>res; });
  }
  getVechicleDetails() {
    return this.http.get<any>(this.resturl + 'reports/vehicleservicelist')
      .toPromise()
      .then(res => { console.log('In getVechicleDetails ' + res); return <any[]>res; });
  }
  getEquipmentFailure() {
    return this.http.get<any>(this.resturl + 'reports/brokenlist')
      .toPromise()
      .then(res => { console.log('In getEquipmentFailure ' + res); return <any[]>res; });
  }

  getPurchaseList() {
    return this.http.get<any>(this.resturl + 'reports/purchaseandrenewallist')
      .toPromise()
      .then(res => { console.log('In getPurchaseList ' + res); return <any[]>res; });
  }
  getMaintenanceCost() {
    return this.http.get<any>(this.resturl + 'reports/amccostlist')
      .toPromise()
      .then(res => { console.log('In getMaintenanceCost ' + res); return <any[]>res; });
  }

  getFourYearExp() {
    return this.http.get<any>(this.resturl + 'reports/fouryearmoneyspentitems')
      .toPromise()
      .then(res => { console.log('In getFourYearExp ' + res); return <any[]>res; });
  }

  addItems(itemObj: any) {
    return this.http.post(this.resturl + 'addItem', itemObj)
      .toPromise();
  }
  updateItems(itemObj: any) {
    return this.http.put(this.resturl + 'updateItem', itemObj)
      .toPromise();
  }
  deleteItems(typeid, id) {
    return this.http.delete(this.resturl + 'deleteItem/' + typeid + '/' + id)
      .toPromise();
  }
}
