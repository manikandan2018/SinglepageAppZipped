import { Injectable } from '@angular/core';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import { Http, Response, Headers } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { NgModel, FormControl } from '@angular/forms';
import 'rxjs/add/operator/map';

declare var $: any;
declare var Materialize: any;

@Injectable()
export class AuthService {

  private event = new BehaviorSubject<number>(0);
  loginEvent$ = this.event.asObservable();

  constructor(private _http: Http,) { }

  login123(username: string, password: string) {

   // let logProcess = this._http.post('https://13.235.74.180:8080/ICMS_UserManagement/validateUsers?userName='+username+'&password='+password, {});

    let logProcess = this._http.post('https://13.235.74.180:8080/ECTSchool/validateUsers?userName='+username+'&password='+password, {});

    //logProcess.subscribe(() => this.event.next(1));
    logProcess.subscribe(
      res => {
        let result = res.json()[0];
        console.log(result);
        localStorage.setItem('currentUser', result.firstname + ' ' + result.lastname);
        localStorage.setItem('userid',result.userid);
        localStorage.setItem('authToken', result.usertoken);
        localStorage.setItem('role', result.role);
        this.event.next(1);
        //this.router.navigate(['/dashboard']);
      },
      err => {
        var $toastContent = $('<span class=""><i class="material-icons left red-text">error</i>Please provide a valid username and password</span>');
        Materialize.toast($toastContent, 2000);     
        this.event.next(1);    
      }
      );
    //  this.router.navigate(['/dashboard']);
    return logProcess;
    // if (username === "admin" && password === "secure") {
    //   localStorage.setItem('currentUser', username);
    //   this.event.next(1);
    //   return true;
    // }
    // return false;
  }
login(username: string, password: string) {

   
      //  if (username === "mmsadmin" && password === "eliteaccess15082019") {
        if (username === "encaenia" && password === "pilot123") {
       localStorage.setItem('currentUser', username);
       localStorage.setItem('role', "0");
       this.event.next(1);
       return true;
      }
      else{
        var $toastContent = $('<span class=""><i class="material-icons left red-text">error</i>Invalid Username / Password</span>');
        Materialize.toast($toastContent, 3000); 
      }
     return false;
  }

recover(email: string) {

   // let logProcess = this._http.post('https://13.235.74.180:8080/ICMS_UserManagement/recoverPassword?email='+email, {});
    let logProcess = this._http.post('https://13.235.74.180:8080/ECTSchool/recoverPassword?email='+email, {});

    //logProcess.subscribe(() => this.event.next(1));
    logProcess.subscribe(
      res => {
        let result = res.json()[0];    
        var $toastContent = $('<span class=""><i class="material-icons left red-text">error</i>Password Sent your registered Email</span>');
        Materialize.toast($toastContent, 3000);         
        this.event.next(1);
        //this.router.navigate(['/dashboard']);
      },
      err => {
        var $toastContent = $('<span class=""><i class="material-icons left red-text">error</i>Please provide a valid Email</span>');
        Materialize.toast($toastContent, 2000);     
        this.event.next(1);    
      }
      );
    //  this.router.navigate(['/dashboard']);
    return logProcess;
    // if (username === "admin" && password === "secure") {
    //   localStorage.setItem('currentUser', username);
    //   this.event.next(1);
    //   return true;
    // }
    // return false;
  }


  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
    this.event.next(0);
  }

  isAuthenicated() {
    let currentUser = localStorage.getItem('currentUser');
    if(currentUser && currentUser !== "") {
      return true;
    }
    return false;
  }

}
 