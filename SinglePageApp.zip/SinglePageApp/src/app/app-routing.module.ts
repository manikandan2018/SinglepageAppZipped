import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
 import { AdminComponent } from './pages/admin/admin.component'; 
 
import { OrderdeliverystatusComponent } from './pages/admin/orderdeliverystatus/orderdeliverystatus.component';
import { OrderdeliverystatusdetailsComponent } from './pages/admin/orderdeliverystatus/orderdeliverystatusdetails/orderdeliverystatusdetails.component';




const routes: Routes = [
  { path: '', redirectTo: 'admin/orderdeliverystatus/orderdeliverystatusdetails', pathMatch: 'full' },
   { path: 'admin', component: AdminComponent },
 
   
 
   { path: 'admin/orderdeliverystatus', component: OrderdeliverystatusComponent },
  { path: 'admin/orderdeliverystatus/orderdeliverystatusdetails', component: OrderdeliverystatusdetailsComponent }

 
  ];

@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forRoot(routes, { useHash: true })]
})
export class AppRoutingModule { }