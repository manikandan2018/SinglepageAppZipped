import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MaterializeModule } from 'angular2-materialize';
import { ChartsModule } from 'ng2-charts';
import { AppComponent } from './app.component';
 
import { AppRoutingModule } from './/app-routing.module';
 import { AdminComponent } from './pages/admin/admin.component';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
 
  import { AuthService } from './services/auth.service';
 
import { PaginationComponent } from './pagination/pagination.component';
import {ScheduleModule} from 'primeng/schedule';
 import { HttpClientModule } from '@angular/common/http';
import { HttpcallsService } from './services/httpcalls.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {DialogModule} from 'primeng/dialog';
import {DropdownModule} from 'primeng/dropdown';
import {TableModule} from 'primeng/table';
import {GrowlModule} from 'primeng/growl';
import { MessageService } from 'primeng/components/common/messageservice';
import {CalendarModule} from 'primeng/calendar';
//import {DropdownModule} from 'primeng/dropdown';
//import { FormsModule, ReactiveFormsModule } from '@angular/forms';
//import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//import { HttpClientModule } from '@angular/common/http';
//import {EventService} from './pages/schedulecmp/EventService'
//import { FullCalendar }      from 'fullcalendar/fullcalendar';
  import {InputSwitchModule} from 'primeng/inputswitch';  
   
 import { OrderdeliverystatusComponent } from './pages/admin/orderdeliverystatus/orderdeliverystatus.component';
 import { OrderdeliverystatusdetailsComponent } from './pages/admin/orderdeliverystatus/orderdeliverystatusdetails/orderdeliverystatusdetails.component';
 
@NgModule({
  declarations: [
    AppComponent,
      
    AdminComponent,    
 
 
    PaginationComponent,
    AdminComponent ,
      
    OrderdeliverystatusComponent,
    OrderdeliverystatusdetailsComponent
     
    
  ],
  imports: [
    BrowserModule,
    MaterializeModule,
    AppRoutingModule,
    FormsModule,
    HttpModule,
    ChartsModule,
    TableModule,DialogModule,
    DropdownModule,
    GrowlModule,
    BrowserAnimationsModule,
    ScheduleModule,
    HttpClientModule,
    CalendarModule,
   
    
    InputSwitchModule 
   ],
  providers: [
    AuthService,HttpcallsService,MessageService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
