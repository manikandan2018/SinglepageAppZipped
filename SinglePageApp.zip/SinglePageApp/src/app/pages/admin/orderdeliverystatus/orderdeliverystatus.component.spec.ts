import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import {OrderdeliverystatusComponent } from './orderdeliverystatus.component';

describe('OrderdeliverystatusComponent', () => {
  let component:OrderdeliverystatusComponent;
  let fixture: ComponentFixture<OrderdeliverystatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OrderdeliverystatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderdeliverystatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
