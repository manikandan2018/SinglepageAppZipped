import { Component, OnInit, AfterViewChecked, ViewChildren, AfterViewInit  } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { NgModel, FormControl } from '@angular/forms';
import 'rxjs/add/operator/map';

declare var $: any;
declare var Materialize: any;

@Component({
  selector: 'app-orderdeliverystatusdetails',
  templateUrl: './orderdeliverystatusdetails.component.html',
  styleUrls: ['./orderdeliverystatusdetails.component.css']
})
export class OrderdeliverystatusdetailsComponent implements  OnInit, AfterViewChecked {

  isLoading: boolean = false;

  basenote: string;
  style: string;
  notelabel: string;
  speedscale: string;
  notespeed: string;
      
  isApproved: string;
  isActive: string;



        id: string;
        infoCode: number;
        deliveryStatus: string;
        date: string;
        shiftTime: string;
        
    deparments: any[] = [];
    shifts: any[] = [];
   
   
  
editId: string;


  router: Router;
   RAGAMusicProfileCode : string;
  @ViewChildren('allTheseThings') things;

    constructor(_router: Router, private _http: Http, private route: ActivatedRoute) {
    this.router = _router;
     this.loadAllDepartment();
     this.loadAllShift();
     
  }
  private loadAllDepartment(){
       this.isLoading = true;
           this._http.get('http://3.109.39.121:8080/Transafe/getAllManagerDetailss')
          .map((res: Response) => res.json())
           .subscribe(data => {
                  this.deparments = data;
                  //console.log(this.deparments);
          },
          err => {
            console.log('Something went wrong!');  
          });
          this.isLoading = false;
      }
      private loadAllShift(){ 
       this.isLoading = true;
           this._http.get('http://3.109.39.121:8080/Transafe/getAllShiftInfos')
          .map((res: Response) => res.json())
           .subscribe(data => {
                  this.shifts = data;
                  ////console.log(this.shifts);
          },
          err => {
            //console.log('Something went wrong!');  
          });
          this.isLoading = false;
      }

  private createReminder() {
    this.isLoading = true;
    this.infoCode = $("#infoCode").val();
    this.shiftTime = $("#shiftTime").val();
    var data = {

      "infoCode": this.infoCode,    
      "deliveryStatus": this.deliveryStatus,
      "date": this.date,    
      "shiftTime": this.shiftTime,
      "isActive":'y',
      "isApproved":'y'    
    };
     
    
    if (this.editId  && this.editId !== ""  && this.editId !== "None") {
      data["id"] = this.editId;
      return this._http.put('http://3.109.39.121:8080/Transafe/updateorderdeliverystatus/', data)
        .subscribe(
        res => {
          console.log(res);
          this.isLoading = false;
          var $toastContent = $('<span>Record has been saved successfully!!</span>');
          Materialize.toast($toastContent, 2000);
          this.router.navigate(['/admin/orderdeliverystatus']);
        },
        err => {
          var $toastContent = $('<span>'+JSON.parse(err["_body"])[0]["errMessage"]+'</span>');
          Materialize.toast($toastContent, 2000);                      
          this.isLoading = false;
        }
        );
    } else {
      return this._http.post('http://localhost:8080/updateDeliveryStatus?infoCode='+this.infoCode+'&deliveryStatus='+this.deliveryStatus, {})
        .subscribe(
        res => {
          console.log(res);
          this.isLoading = false;
          var $toastContent = $('<span>Record has been saved successfully!!</span>');
          Materialize.toast($toastContent, 2000);
          this.router.navigate(['/admin/orderdeliverystatus/orderdeliverystatusdetails']);
        },
        err => {
          var $toastContent = $('<span>'+JSON.parse(err["_body"])[0]["errMessage"]+'</span>');
          Materialize.toast($toastContent, 2000);            
          this.isLoading = false;
        }
        );
    }
  }

  public moveNext(event, tab) {
    $('.collapsible').collapsible('open', tab);
  }

  ngAfterViewInit() {
    this.things.changes.subscribe(t => {
      $("select").material_select();
    })
    
  }

  ngAfterViewChecked() {
   
    Materialize.updateTextFields();

  }
  ngOnInit() {
    $("select").material_select();
    $('.collapsible').collapsible({      
      onOpen: function(el) {  Materialize.updateTextFields(); }
    });

    this.route
      .queryParamMap
      .map(params => params.get('session_id') || 'None')
      .subscribe(val => this.editId = val);

    console.log(this.editId);

    if (this.editId  && this.editId !== ""  && this.editId !== "None") {
      this.isLoading = true;
      return this._http.get('http://3.109.39.121:8080/Transafe/getorderdeliverystatusById/' + this.editId)
        .map((res: Response) => res.json())
        .subscribe(data => {
          var record = data[0];
      

          this.infoCode = record["infoCode"];
          this.deliveryStatus = record["deliveryStatus"];
          this.date = record["date"];
          this.shiftTime = record["shiftTime"];
      
           $('#infoCode').val(this.infoCode);
           $('#shiftTime').val(this.shiftTime); 
          
          $("select").material_select();         
          Materialize.updateTextFields();
          this.isLoading = false;
          //debugger;
        },
        err => {
          console.log('Something went wrong!');
          this.isLoading = false;
        });
    }



    Materialize.updateTextFields();
  }





}




