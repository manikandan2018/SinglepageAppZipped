import { Component, OnInit, AfterViewChecked, ViewChildren, AfterViewInit  } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { NgModel, FormControl } from '@angular/forms';
import 'rxjs/add/operator/map';

declare var $: any;
declare var Materialize: any;

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {



  //constructor() { }

  ngOnInit() {		 
		   $('.collapsible').collapsible({      
		      onOpen: function(el) {  Materialize.updateTextFields(); }
		    });
    }


public moveNext(event, tab) {
    $('.collapsible').collapsible('open', tab);
  }
}
